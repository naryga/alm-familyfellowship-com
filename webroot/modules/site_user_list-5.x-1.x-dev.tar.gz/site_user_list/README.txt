The site_user_list module provides a listing of all the users on
the site, with access to all the profile.module fields.

Your user will need to have the 'CREATE VIEW' privilege on the
MySQL database if you want to use the view version (which is 
preferred to a table).

Once you enable the module, go to the settings page, and select
which profile fields are available for display and what order
they should appear in by putting numbers into the leftmost
boxes.  You should also choose which fields are visible by
default.

