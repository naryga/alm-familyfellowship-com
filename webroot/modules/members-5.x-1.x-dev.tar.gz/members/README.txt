Members.module
------

Members provides an alternate listing style to profile.module, with a
focus on tabular display and an emphasis on roles (including listing by
role).


Currently maintained by:

James Walker <walkah@walkah.net>
Wim Mostrey <wim@mostrey.be>
